const users = {
  "kldmn": {
    role: "admin",
    invited: ["kldmn1"],
    earnings: 200,
    wallet: "UQDQ0aBNyaYGtI8ANjEpUAQkpYqE3NPwWUiatzTigntjNHPu"
  },
  "kldmn1": {
    role: "user",
    invited: [],
    earnings: 0
  }
};

function showTab(tabId) {
  document.querySelectorAll(".tab-content").forEach(tab => tab.classList.remove("active"));
  document.getElementById(tabId).classList.add("active");
}

function updateAccountView(userId = "kldmn") {
  const user = users[userId];
  const section = document.getElementById("referralsSection");

  if (user.role === "user") {
    section.style.display = "none";
  } else {
    section.style.display = "block";
    updateReferralsTable(userId);
  }
}

function updateReferralsTable(adminId) {
  const table = document.getElementById("referralsTable").querySelector("tbody");
  table.innerHTML = "";

  const admin = users[adminId];
  if (!admin || !admin.invited.length) {
    table.innerHTML = "<tr><td colspan='2'>Нет приглашённых</td></tr>";
    return;
  }

  admin.invited.forEach(userId => {
    const user = users[userId];
    const row = document.createElement("tr");
    row.innerHTML = `<td>${userId}</td><td>${user.earnings} TON</td>`;
    table.appendChild(row);
  });
}

function buyProduct(userId, productId, productPrice) {
  const user = users[userId];
  if (!user || user.earnings < productPrice) return alert("❌ Недостаточно средств");

  const referralBonus = productPrice * 0.1;
  const referrerId = user.invitedBy;

  if (referrerId && users[referrerId] && users[referrerId].role === "admin") {
    users[referrerId].earnings += referralBonus;
    updateReferralsTable(referrerId);
  }

  const amountNano = productPrice * 1e9;
  const paymentLink = `ton://transfer/${users.kldmn.wallet}?amount=${amountNano}&text=buy_${productId}_${userId}`;
  alert(`✅ Оплатите ${productPrice} TON по ссылке:\n${paymentLink}`);
}